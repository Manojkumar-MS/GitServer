﻿/*
 * Created by SharpDevelop.
 * User: anomanoj
 * Date: 09-12-2017
 * Time: 01:15
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AWS_CW_Dashboard
{
	/// <summary>
	/// Description of AllMetrics.
	/// </summary>
	public class AllMetrics
	{
		public string TimeStamp {get;set;}
		public double Minimum {get;set;}
		public double Average {get;set;}
		public double Maximum {get;set;}
		public double Sum {get;set;}
		public double SampleCount {get;set;}
		
		public AllMetrics(string time, double min, double avg, double max,double sum, double sc)
		{
			this.TimeStamp=time;
			this.Minimum = min;
			this.Average = avg;
			this.Maximum = max;
			this.Sum = sum;
			this.SampleCount=sc;
		}
	}
}
