﻿/*
 * Created by SharpDevelop.
 * User: anomanoj
 * Date: 09-12-2017
 * Time: 00:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace AWS_CW_Dashboard
{
	/// <summary>
	/// Description of Lambda_Dimensions.
	/// </summary>
	public partial class Lambda_Dimensions : Form
	{
		public Lambda_Dimensions()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			this.ControlBox = false;
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Btn_SaveClick(object sender, EventArgs e)
		{
			if (textBox1.Text!="") {
				MainForm mf = new MainForm();
				//mf.setLamDimension(textBox1.Text);
				TopLevel=false;
				Close();
			}
		}
		
	}
}
