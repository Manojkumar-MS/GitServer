﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 11/28/2017
 * Time: 5:17 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace AWS_CW_Dashboard
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.ComboBox cmbServices;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cmbMetrics;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.DateTimePicker dateTimePicker3;
		private System.Windows.Forms.DateTimePicker dateTimePicker4;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbStatistics;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btn_metrics;
		private System.Windows.Forms.Button btn_Proxy;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Button btn_e2e;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.ComboBox comboBox2;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.cmbServices = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.cmbMetrics = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.cmbStatistics = new System.Windows.Forms.ComboBox();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label6 = new System.Windows.Forms.Label();
			this.btn_metrics = new System.Windows.Forms.Button();
			this.btn_Proxy = new System.Windows.Forms.Button();
			this.label7 = new System.Windows.Forms.Label();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.btn_e2e = new System.Windows.Forms.Button();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.tabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
			this.SuspendLayout();
			// 
			// cmbServices
			// 
			this.cmbServices.FormattingEnabled = true;
			this.cmbServices.Items.AddRange(new object[] {
			"S3",
			"Lambda"});
			this.cmbServices.Location = new System.Drawing.Point(118, 38);
			this.cmbServices.Name = "cmbServices";
			this.cmbServices.Size = new System.Drawing.Size(121, 21);
			this.cmbServices.TabIndex = 0;
			this.cmbServices.SelectedIndexChanged += new System.EventHandler(this.CmbServicesSelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(20, 41);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Choose Service :";
			// 
			// cmbMetrics
			// 
			this.cmbMetrics.FormattingEnabled = true;
			this.cmbMetrics.Location = new System.Drawing.Point(118, 101);
			this.cmbMetrics.Name = "cmbMetrics";
			this.cmbMetrics.Size = new System.Drawing.Size(121, 21);
			this.cmbMetrics.TabIndex = 2;
			this.cmbMetrics.SelectedIndexChanged += new System.EventHandler(this.CmbMetricsSelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(15, 104);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 23);
			this.label2.TabIndex = 3;
			this.label2.Text = "  Choose Metrics :";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(46, 170);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(66, 20);
			this.label3.TabIndex = 5;
			this.label3.Text = "Start Time :";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.AllowDrop = true;
			this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
			this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker1.Location = new System.Drawing.Point(118, 170);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(103, 20);
			this.dateTimePicker1.TabIndex = 6;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.CustomFormat = "HH:mm:ss";
			this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker2.Location = new System.Drawing.Point(227, 170);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.ShowUpDown = true;
			this.dateTimePicker2.Size = new System.Drawing.Size(70, 20);
			this.dateTimePicker2.TabIndex = 7;
			this.dateTimePicker2.Value = new System.DateTime(2017, 12, 8, 15, 37, 0, 0);
			// 
			// dateTimePicker3
			// 
			this.dateTimePicker3.CustomFormat = "HH:mm:ss";
			this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker3.Location = new System.Drawing.Point(227, 204);
			this.dateTimePicker3.Name = "dateTimePicker3";
			this.dateTimePicker3.ShowUpDown = true;
			this.dateTimePicker3.Size = new System.Drawing.Size(70, 20);
			this.dateTimePicker3.TabIndex = 10;
			// 
			// dateTimePicker4
			// 
			this.dateTimePicker4.AllowDrop = true;
			this.dateTimePicker4.CustomFormat = "yyyy-MM-dd";
			this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimePicker4.Location = new System.Drawing.Point(118, 204);
			this.dateTimePicker4.Name = "dateTimePicker4";
			this.dateTimePicker4.Size = new System.Drawing.Size(103, 20);
			this.dateTimePicker4.TabIndex = 9;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(43, 204);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(66, 20);
			this.label4.TabIndex = 8;
			this.label4.Text = "  End Time :";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(16, 140);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(94, 23);
			this.label5.TabIndex = 12;
			this.label5.Text = "            Statistics :";
			// 
			// cmbStatistics
			// 
			this.cmbStatistics.FormattingEnabled = true;
			this.cmbStatistics.Location = new System.Drawing.Point(118, 137);
			this.cmbStatistics.Name = "cmbStatistics";
			this.cmbStatistics.Size = new System.Drawing.Size(121, 21);
			this.cmbStatistics.TabIndex = 11;
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Increment = new decimal(new int[] {
			60,
			0,
			0,
			0});
			this.numericUpDown1.Location = new System.Drawing.Point(118, 242);
			this.numericUpDown1.Maximum = new decimal(new int[] {
			86400,
			0,
			0,
			0});
			this.numericUpDown1.Minimum = new decimal(new int[] {
			60,
			0,
			0,
			0});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(57, 20);
			this.numericUpDown1.TabIndex = 13;
			this.numericUpDown1.Value = new decimal(new int[] {
			60,
			0,
			0,
			0});
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(44, 244);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(66, 20);
			this.label6.TabIndex = 14;
			this.label6.Text = "       Period :";
			// 
			// btn_metrics
			// 
			this.btn_metrics.Location = new System.Drawing.Point(118, 284);
			this.btn_metrics.Name = "btn_metrics";
			this.btn_metrics.Size = new System.Drawing.Size(94, 23);
			this.btn_metrics.TabIndex = 16;
			this.btn_metrics.Text = "Get Metrics";
			this.btn_metrics.UseVisualStyleBackColor = true;
			this.btn_metrics.Click += new System.EventHandler(this.Btn_metricsClick);
			// 
			// btn_Proxy
			// 
			this.btn_Proxy.Location = new System.Drawing.Point(241, 284);
			this.btn_Proxy.Name = "btn_Proxy";
			this.btn_Proxy.Size = new System.Drawing.Size(94, 23);
			this.btn_Proxy.TabIndex = 17;
			this.btn_Proxy.Text = "Configure Proxy";
			this.btn_Proxy.UseVisualStyleBackColor = true;
			this.btn_Proxy.Click += new System.EventHandler(this.Btn_ProxyClick);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(13, 69);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 23);
			this.label7.TabIndex = 18;
			this.label7.Text = "Enter Dimensions :";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Location = new System.Drawing.Point(358, 12);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(468, 325);
			this.tabControl1.TabIndex = 21;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.dataGridView1);
			this.tabPage1.Controls.Add(this.btn_e2e);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(460, 299);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "List View";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(6, 7);
			this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(449, 256);
			this.dataGridView1.TabIndex = 1;
			// 
			// btn_e2e
			// 
			this.btn_e2e.Location = new System.Drawing.Point(155, 267);
			this.btn_e2e.Margin = new System.Windows.Forms.Padding(2);
			this.btn_e2e.Name = "btn_e2e";
			this.btn_e2e.Size = new System.Drawing.Size(123, 19);
			this.btn_e2e.TabIndex = 1;
			this.btn_e2e.Text = "Export to Excel";
			this.btn_e2e.UseVisualStyleBackColor = true;
			this.btn_e2e.Click += new System.EventHandler(this.Btn_e2eClick);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.chart1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(460, 299);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Graph";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// chart1
			// 
			chartArea1.Name = "ChartArea1";
			this.chart1.ChartAreas.Add(chartArea1);
			legend1.Name = "Legend1";
			this.chart1.Legends.Add(legend1);
			this.chart1.Location = new System.Drawing.Point(6, 10);
			this.chart1.Name = "chart1";
			series1.ChartArea = "ChartArea1";
			series1.Legend = "Legend1";
			series1.Name = "Series1";
			this.chart1.Series.Add(series1);
			this.chart1.Size = new System.Drawing.Size(448, 286);
			this.chart1.TabIndex = 0;
			this.chart1.Text = "chart1";
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(118, 69);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(103, 21);
			this.comboBox1.TabIndex = 22;
			// 
			// comboBox2
			// 
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Location = new System.Drawing.Point(227, 69);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(108, 21);
			this.comboBox2.TabIndex = 23;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(838, 349);
			this.Controls.Add(this.comboBox2);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.btn_Proxy);
			this.Controls.Add(this.btn_metrics);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.numericUpDown1);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.cmbStatistics);
			this.Controls.Add(this.dateTimePicker3);
			this.Controls.Add(this.dateTimePicker4);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.dateTimePicker2);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmbMetrics);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cmbServices);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "AWS_CW_Dashboard";
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.tabPage2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
			this.ResumeLayout(false);

		}
	}
}
