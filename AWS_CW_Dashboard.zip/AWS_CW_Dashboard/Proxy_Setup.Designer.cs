﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/8/2017
 * Time: 7:11 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace AWS_CW_Dashboard
{
	partial class Proxy_Setup
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txt_user;
		private System.Windows.Forms.TextBox txt_pwd;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txt_host;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txt_port;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btn_save;
		private System.Windows.Forms.Button btn_reset;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txt_user = new System.Windows.Forms.TextBox();
			this.txt_pwd = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txt_host = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txt_port = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btn_save = new System.Windows.Forms.Button();
			this.btn_reset = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 46);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(85, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "User Name:";
			// 
			// txt_user
			// 
			this.txt_user.Location = new System.Drawing.Point(103, 43);
			this.txt_user.Name = "txt_user";
			this.txt_user.Size = new System.Drawing.Size(169, 20);
			this.txt_user.TabIndex = 1;
			// 
			// txt_pwd
			// 
			this.txt_pwd.Location = new System.Drawing.Point(103, 81);
			this.txt_pwd.Name = "txt_pwd";
			this.txt_pwd.PasswordChar = '*';
			this.txt_pwd.Size = new System.Drawing.Size(169, 20);
			this.txt_pwd.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(12, 84);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(85, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "Password :";
			// 
			// txt_host
			// 
			this.txt_host.Location = new System.Drawing.Point(103, 120);
			this.txt_host.Name = "txt_host";
			this.txt_host.Size = new System.Drawing.Size(169, 20);
			this.txt_host.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(12, 123);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(85, 23);
			this.label3.TabIndex = 4;
			this.label3.Text = "Proxy Host:";
			// 
			// txt_port
			// 
			this.txt_port.Location = new System.Drawing.Point(103, 155);
			this.txt_port.Name = "txt_port";
			this.txt_port.Size = new System.Drawing.Size(169, 20);
			this.txt_port.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(12, 158);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(85, 23);
			this.label4.TabIndex = 6;
			this.label4.Text = "Proxy Port:";
			// 
			// btn_save
			// 
			this.btn_save.Location = new System.Drawing.Point(88, 198);
			this.btn_save.Name = "btn_save";
			this.btn_save.Size = new System.Drawing.Size(82, 28);
			this.btn_save.TabIndex = 8;
			this.btn_save.Text = "Save";
			this.btn_save.UseVisualStyleBackColor = true;
			this.btn_save.Click += new System.EventHandler(this.Btn_saveClick);
			// 
			// btn_reset
			// 
			this.btn_reset.Location = new System.Drawing.Point(190, 198);
			this.btn_reset.Name = "btn_reset";
			this.btn_reset.Size = new System.Drawing.Size(82, 28);
			this.btn_reset.TabIndex = 9;
			this.btn_reset.Text = "Reset";
			this.btn_reset.UseVisualStyleBackColor = true;
			this.btn_reset.Click += new System.EventHandler(this.Btn_resetClick);
			// 
			// Proxy_Setup
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 262);
			this.Controls.Add(this.btn_reset);
			this.Controls.Add(this.btn_save);
			this.Controls.Add(this.txt_port);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txt_host);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txt_pwd);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txt_user);
			this.Controls.Add(this.label1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Proxy_Setup";
			this.Text = "Proxy_Setup";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
