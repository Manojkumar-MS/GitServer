﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 11/28/2017
 * Time: 5:17 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using Amazon;
using Amazon.CloudWatch;
using Amazon.CloudWatch.Model;
using ClosedXML.Excel;

namespace AWS_CW_Dashboard
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		private string mUnit;
		private string nameS;
		private string mName;
		private string proxyUser;
		private string proxyPassword;
		private string proxyhost;
		private int proxyPort;
		public string BucketName;
		public string FilterID;
		public string FunctionName;
		Dimension S3_bName = new Dimension();
		Dimension S3_Filter = new Dimension();
		Dimension La_fName = new Dimension();
	
		private List<AllMetrics> li = new List<AllMetrics>();
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			Amazon.Util.ProfileManager.RegisterProfile("default", "AKIAI4TPIF6A63JL2KXA", "atThfA+c86rGMeb5q4YvbKZJg9P9xQBUJBQlWcF5");
			InitializeComponent();
			
//			using (var cw = new AmazonCloudWatchClient())
//			{
//				var r = new ListMetricsRequest();
//						var r1 = cw.ListMetrics(r);
//						foreach (var element in r1.Metrics) {
//							MessageBox.Show(element.Namespace);
//						}		
//				
//			}
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void CmbServicesSelectedIndexChanged(object sender, EventArgs e)
		{
			List<String> comboSource = new List<string>();
			BindingSource src = new BindingSource();
			cmbMetrics.Items.Clear();
			cmbMetrics.SelectedIndex = -1;
			cmbMetrics.SelectedText = "";

			if (cmbServices.SelectedIndex == 0) {
				nameS="S3";
				List <string> s3 = new List<string>(){"AllRequests","GetRequests","PutRequests","DeleteRequests","HeadRequests","PostRequests","ListRequests","BytesDownloaded","BytesUploaded","4xxErrors","5xxErrors","FirstByteLatency","TotalRequestLatency"};
				foreach (var element in s3) {
					cmbMetrics.Items.Add(element);
				}
				//textBox2.Visible = true;
				comboBox1.Items.Clear();
				comboBox1.SelectedIndex=-1;
				comboBox1.SelectedText = "";
				string path ="S3.csv";
				string[] t;
				StreamReader sr = new StreamReader(path);
				while (sr.Peek()>0) {
					t=sr.ReadLine().Split(',');
					comboBox1.Items.Add(t[0]);
					comboBox2.Items.Add(t[1]);
				}
				comboBox1.SelectedIndex=-1;
				comboBox2.Visible = true;
				
//				S3_Dimensions s3D = new S3_Dimensions();
//				s3D.Show();
//				s3D.TopLevel=true;"
			}
			if (cmbServices.SelectedIndex == 1) {
				nameS="Lambda";
				//textBox2.Visible=false;
				List <string> lambda = new List<string>(){"Invocations","Errors","DeadLetterErrors","Duration","Throttles","IteratorAge","ConcurrentExecutions","UnreservedConcurrentExecutions"};
				foreach (var element in lambda) {
					cmbMetrics.Items.Add(element);
				}
				comboBox1.Items.Clear();
				comboBox1.SelectedIndex=-1;
				comboBox1.SelectedText = "";
				string path ="Lambda.csv";
				StreamReader sr = new StreamReader(path);
				while (sr.Peek()>0) {
					comboBox1.Items.Add(sr.ReadLine());
				}
				comboBox1.SelectedIndex=-1;
				comboBox2.Visible = false;
//				Lambda_Dimensions ld = new Lambda_Dimensions();
//				ld.Show();
//				ld.TopLevel = true;
			}
		}
		void CmbMetricsSelectedIndexChanged(object sender, EventArgs e)
		{
			cmbStatistics.Items.Clear();
			cmbStatistics.SelectedIndex = -1;
			cmbStatistics.SelectedText = "";
			
			List <string> uCount = new List<string>(){"Invocations","Errors","DeadLetterErrors","Throttles","ConcurrentExecutions","UnreservedConcurrentExecutions","AllRequests","GetRequests","PutRequests","DeleteRequests","HeadRequests","PostRequests","ListRequests","4xxErrors","5xxErrors"};
			List <string> mSec = new List<string>(){"Duration","IteratorAge","FirstByteLatency","TotalRequestLatency"};
			List <string> byt = new List<string>() {"BytesDownloaded","BytesUploaded"};
			List <string> sStat = new List<string>(){"AllRequests","GetRequests","PutRequests","DeleteRequests","HeadRequests","PostRequests","ListRequests"};
			List<string> stats = new List<string>() {"All","Minimum","Average","Maximum","SampleCount","Sum"};
			if (uCount.Contains(cmbMetrics.SelectedItem.ToString())) {
				mUnit="Count";
				if (sStat.Contains(cmbMetrics.SelectedItem.ToString())) {
					stats.Clear();
					stats.Add("Sum");
				}
			}
			if (mSec.Contains(cmbMetrics.SelectedIndex.ToString())) {
				mUnit="Milliseconds";
			}
			if (byt.Contains(cmbMetrics.SelectedIndex.ToString())) {
				mUnit="Bytes";
			}
			foreach (var element in stats) {
				cmbStatistics.Items.Add(element);
			}
			mName = cmbMetrics.SelectedItem.ToString();
		}
		void Btn_metricsClick(object sender, EventArgs e)
		{
			List<string> stats;
			
			var src = new BindingSource();
			string endTime = dateTimePicker3.Value.ToString("yyyy-MM-dd")+" "+dateTimePicker4.Value.ToString("HH:mm:ss");
			string startTime = dateTimePicker1.Value.ToString("yyyy-MM-dd")+" "+dateTimePicker2.Value.ToString("HH:mm:ss");
			try {
				if (nameS == "S3") { 
					if (cmbStatistics.SelectedItem.ToString()=="All") {
						stats = new List<string>(){"Minimum","Average","Maximum","SampleCount","Sum"};
					}
					else
						stats = new List<string>{cmbStatistics.SelectedItem.ToString()};
					using  (var cw = new AmazonCloudWatchClient())
					{
						//string s = textBox1.Text;
						string s =comboBox1.SelectedItem.ToString();
						string s1 = comboBox2.SelectedItem.ToString();
						S3_bName.Name="BucketName";
						S3_bName.Value=s;
						S3_Filter.Name="FilterId";
						S3_Filter.Value=s1;
						
						var request = new GetMetricStatisticsRequest
		                {
							Dimensions = new List<Dimension>() { S3_bName,S3_Filter },
		                    EndTime = DateTime.Parse(endTime),
		                    MetricName = mName,
		                    Namespace = "AWS/"+nameS,
		                    // Get statistics by day.
		                    Period = (int)numericUpDown1.Value,
		                    // Get statistics for the past month.
		                    StartTime = DateTime.Parse(startTime),
		                    Statistics = stats,
		                    Unit = mUnit
		                };
						var response = cw.GetMetricStatistics(request);
						//List<AllMetrics> li = new List<AllMetrics>();
						li.Clear();
						foreach (var dataPoint in response.Datapoints) {
							
							li.Add(new AllMetrics(dataPoint.Timestamp.ToString("MM/dd HH:mm"),dataPoint.Minimum,dataPoint.Average,dataPoint.Maximum,dataPoint.Sum,dataPoint.SampleCount));
						
						}
						chart1.Series["Series1"].Points.Clear();
						foreach (var element in li) {
							chart1.Series["Series1"].Points.AddXY(element.TimeStamp,element.Average);
						}
					}
				}
				else
				{
					string s = comboBox1.SelectedItem.ToString();
					S3_bName.Name="FunctionName";
					S3_bName.Value=s;
					if (cmbStatistics.SelectedItem.ToString()=="All") {
						stats = new List<string>(){"Minimum","Average","Maximum","SampleCount","Sum"};
					}
					else
						stats = new List<string>{cmbStatistics.SelectedItem.ToString()};
					using  (var cw = new AmazonCloudWatchClient())
					{
						var request = new GetMetricStatisticsRequest
		                {
		                    Dimensions = new List<Dimension>() { S3_bName},
		                    EndTime = DateTime.Parse(endTime),
		                    MetricName = mName,
		                    Namespace = "AWS/"+nameS,
		                    Period = (int)numericUpDown1.Value,
		                    StartTime = DateTime.Parse(startTime),
		                    Statistics = stats,
		                    Unit = mUnit
		                };
						var response = cw.GetMetricStatistics(request);
						
						
						foreach (var dataPoint in response.Datapoints) {
							
							li.Add(new AllMetrics(dataPoint.Timestamp.ToString("MM/dd HH:mm"),dataPoint.Minimum,dataPoint.Average,dataPoint.Maximum,dataPoint.Sum,dataPoint.SampleCount));
						
						}

					}
				}
				src.DataSource = li;
				dataGridView1.DataSource=src;
			} catch (Exception ex) {
				MessageBox.Show(ex.Message);
			}
		}
		void Btn_ProxyClick(object sender, EventArgs e)
		{
			Proxy_Setup ps = new Proxy_Setup();
			ps.setProxyFields(getProxy());
			ps.Show();
			ps.TopLevel = true;
		}
		public void setProxy(string pUser, string pwd, string host, string port)
		{
			AWSConfigs.ProxyConfig.Username = pUser;
			AWSConfigs.ProxyConfig.Password = pwd;
			AWSConfigs.ProxyConfig.Host = host;
			AWSConfigs.ProxyConfig.Port = Convert.ToInt32(port);
		}
		public List<string> getProxy()
		{
			return new List<string>(){proxyUser,proxyPassword,proxyhost,proxyPort.ToString()};
		}
//		public void setS3Dimension(Dimension name, Dimension filter)
//		{			
//			S3_bName = name;
//			MessageBox.Show(S3_bName.Value);
//			bu.Add(S3_bName.Value);
//			fi.Add(S3_Filter.Value);
//			
//			S3_Filter = filter;
//			//MessageBox.Show(BucketName);
//		}
//		public void setLamDimension(string fName)
//		{
//			this.FunctionName = fName;
//		}
		void Btn_e2eClick(object sender, EventArgs e)
		{
			List<xlHeader> a =new List<xlHeader>();
			a.Add(new xlHeader("TimeStamp","Minimum","Average","Maximum","Sum","Sample Count"));
			var src = new BindingSource();			
			src.DataSource = li;
			var workbook = new XLWorkbook();
			var worksheet = workbook.Worksheets.Add(mName);
			worksheet.Cell(3,1).InsertData(src);
			src.DataSource = a;
			worksheet.Cell(2,1).InsertData(src);
			src.DataSource = new List<string>(){mName};
			worksheet.Cell(1,1).InsertData(src);
			workbook.SaveAs("Report_"+DateTime.Now+".xlsx");
		}
		
	}
}
