﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/13/2017
 * Time: 6:52 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace AWS_CW_Dashboard
{
	/// <summary>
	/// Description of S3_Dashboard.
	/// </summary>
	public partial class S3_Dashboard : Form
	{
		public S3_Dashboard()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
