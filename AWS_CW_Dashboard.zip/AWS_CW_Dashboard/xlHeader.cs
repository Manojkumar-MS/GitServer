﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/11/2017
 * Time: 7:25 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AWS_CW_Dashboard
{
	/// <summary>
	/// Description of xlHeader.
	/// </summary>
	public class xlHeader
	{
		public string TimeStamp {get;set;}
		public string Minimum {get;set;}
		public string Average {get;set;}
		public string Maximum {get;set;}
		public string Sum {get;set;}
		public string SampleCount {get;set;}
		
		public xlHeader(string time, string min, string avg, string max,string sum, string sc)
		{
			this.TimeStamp=time;
			this.Minimum = min;
			this.Average = avg;
			this.Maximum = max;
			this.Sum = sum;
			this.SampleCount=sc;
		}
	}
}
