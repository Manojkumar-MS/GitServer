﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/8/2017
 * Time: 7:11 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace AWS_CW_Dashboard
{
	/// <summary>
	/// Description of Proxy_Setup.
	/// </summary>
	public partial class Proxy_Setup : Form
	{
		public Proxy_Setup()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			this.ControlBox = false;
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		public void setProxyFields(List<string> li)
		{
			txt_user.Text=li[0];
			txt_pwd.Text=li[1];
			txt_host.Text=li[2];
			txt_port.Text=li[3];
		}
		void Btn_saveClick(object sender, EventArgs e)
		{
			MainForm mf = new MainForm();
			if (txt_user.Text!="" && txt_pwd.Text !="" && txt_host.Text!="" && txt_port.Text!="") {
				mf.setProxy(txt_user.Text,txt_pwd.Text,txt_host.Text,txt_port.Text);
				TopLevel=false;
				Close();
			}
			else
				MessageBox.Show("All fields are mandatory");			
		}
		void Btn_resetClick(object sender, EventArgs e)
		{
			txt_user.Clear();
			txt_pwd.Clear();
			txt_host.Clear();
			txt_port.Clear();
		}
		
	}
}
