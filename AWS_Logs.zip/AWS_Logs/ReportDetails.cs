﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/14/2017
 * Time: 6:56 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AWS_Logs
{
	/// <summary>
	/// Description of ReportDetails.
	/// </summary>
	public class ReportDetails
	{
		public string Msg{get;set;}
		public string Ingestion{get;set;}
		public string Timestamp{get;set;}
		public string Duration{get;set;}
		public string bDuration{get;set;}
		public string mSize{get;set;}
		public string mUsed{get;set;}
		
		public ReportDetails(string msg, string timestamp, string ingestion, string dur, string bDur,string msize, string MUsed )
		{
			this.Msg = msg;
			this.Ingestion=ingestion;
			this.Timestamp=timestamp;
			this.Duration = dur;
			this.bDuration = bDur;
			this.mSize = msize;
			this.mUsed=MUsed;
		}
	}
}
