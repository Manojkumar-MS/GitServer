﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/13/2017
 * Time: 10:16 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using Amazon;
using Amazon.CloudWatchLogs;
using Amazon.CloudWatchLogs.Model;
using System.Reflection;
using System.Data;
using ClosedXML.Excel;

namespace AWS_Logs
{
	class Program
	{
		public static void Main(string[] args)
		{
			string path = "MySample.txt";
			GetLogEventsResponse response;
			List<string> li = new List<string>();
			List<details> stt = new List<details>();
			List<details> edt = new List<details>();
			List<ReportDetails> rpt = new List<ReportDetails>();
			List<xlUpload> finalList = new List<xlUpload>();
			
			AWSConfigs.ProxyConfig.Username = "";
			AWSConfigs.ProxyConfig.Password = "";
			AWSConfigs.ProxyConfig.Host = "";
			AWSConfigs.ProxyConfig.Port = ;
			
			using(var cwl = new AmazonCloudWatchLogsClient())
			{
				var sRequest = new DescribeLogStreamsRequest("/aws/lambda/manoj");
				var sResponse = cwl.DescribeLogStreams(sRequest);
			
				foreach (var element in sResponse.LogStreams) {
					li.Add(element.LogStreamName);
				}
				
				string st ="2017-12-15 19:20:00";
				string et="2017-12-15 19:25:00";
				
				string logstream="";
				for (int i = 0; i < li.Count; i++) {
					if (li[i].Contains("2017/12/15")) {
						logstream = li[i];
						break;
					}
				}
				var request = new GetLogEventsRequest{
					LogGroupName="/aws/lambda/manoj",
					LogStreamName =logstream,
					StartFromHead = true,
					StartTime=DateTime.Parse(st),
					EndTime=DateTime.Parse(et),
				};
				response = cwl.GetLogEvents(request);
				File.Create(path).Close();
				using (StreamWriter sw = File.AppendText(path)) {
					foreach (var resp in response.Events) {
						sw.WriteLine(resp.Message+"\t"+resp.Timestamp+"\t"+resp.IngestionTime);
					}
				}
			}
			ExtractThread ex = new ExtractThread();
			Thread stThread = new Thread(()=>stt= (ex.ExtractStartTime(response)));
			Thread etThread = new Thread(()=>edt=(ex.ExtractEndTime(response)));
			Thread rtThread = new Thread(()=>rpt=(ex.ExtractReport(response)));
			etThread.Start();
			stThread.Start();
			rtThread.Start();
			while (rtThread.IsAlive || stThread.IsAlive || etThread.IsAlive){}
			int ii;
			int jj;
			foreach (var msg in stt) {
				ii=edt.FindIndex(x=> x.Msg == msg.Msg);
				jj=rpt.FindIndex(x=>x.Msg == msg.Msg);
				finalList.Add(new xlUpload(msg.Msg,DateTime.Parse(msg.Timestamp),DateTime.Parse(edt[ii].Timestamp),DateTime.Parse(rpt[jj].Timestamp),Convert.ToDouble(rpt[jj].Duration),Convert.ToDouble(rpt[jj].bDuration),rpt[jj].mSize,rpt[jj].mUsed));
			}
			
			DataTable dataTable = new DataTable(typeof(xlUpload).Name);
            //Get all the properties
            PropertyInfo[] Props = typeof(xlUpload).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (xlUpload item in finalList)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }   
			var workbook = new XLWorkbook();
			var worksheet = workbook.AddWorksheet(dataTable);
			workbook.SaveAs("Z:\\aws"+"\\Report.xlsx");
			Console.WriteLine(finalList.Count);
			Console.ReadKey(true);
		}
	}
}