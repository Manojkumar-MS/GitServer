﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/13/2017
 * Time: 10:16 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using Amazon;
using Amazon.CloudWatchLogs;
using Amazon.CloudWatchLogs.Model;
using System.Reflection;
using System.Data;
using ClosedXML.Excel;

namespace AWS_Logs
{
	class Program
	{
		public static void Main(string[] args)
		{
			string path = "MySample.txt";
			GetLogEventsResponse response;
			List<string> li = new List<string>();
			List<details> stt = new List<details>();
			List<details> edt = new List<details>();
			List<ReportDetails> rpt = new List<ReportDetails>();
			List<xlUpload> finalList = new List<xlUpload>();
			string username;
			string pwd="";
			string proxy;
			int port;
			Console.WriteLine("Enter Network Credentials for Proxy Authentication");
			Console.Write("UserName: ");
			username = Console.ReadLine();
			Console.WriteLine(username);
			Console.Write("Enter your password: ");
			ConsoleKeyInfo key;
			
			do
			{
			    key = Console.ReadKey(true);
			    if (key.Key != ConsoleKey.Backspace)
			    {
			        pwd += key.KeyChar;
			        Console.Write("*");
			    }
			    else
			    {
			        Console.Write("\b");
			    }
			}
			while (key.Key != ConsoleKey.Enter);
			string pass = pwd;
			string user = username;
			Console.Write("Enter Proxy URL:");
			proxy = Console.ReadLine();
			Console.Write("Enter Proxy Port:");
			port = Convert.ToInt32( Console.ReadLine());
			
			List<string> lambdaFunctions = new List<string>();
			string temp;
			string st ="2017-12-15 19:20:00";
			string et="2017-12-15 19:25:00";
			
			Console.WriteLine("Enter Start Date and End Date in the format 'yyyy-MM-dd HH:mm:ss'");
			Console.Write("Start Date: ");
			st = Console.ReadLine();
			Console.Write("End Date: ");
			et = Console.ReadLine();
			
			string filepath;
			Console.Write("Enter the Report file path and name (without .xlsx), sample z:\\aws\\");
			filepath = Console.ReadLine();
			
			using(StreamReader sr = new StreamReader("LambdaFunctions.txt"))
			{
				if ((temp=sr.ReadLine())!=null) {
					lambdaFunctions.Add(temp);
				}
			}
			for (int i = 0; i < lambdaFunctions.Count; i++) {
				
				AWSConfigs.ProxyConfig.Username = user;
				AWSConfigs.ProxyConfig.Password = pass;
				AWSConfigs.ProxyConfig.Host = proxy;
				AWSConfigs.ProxyConfig.Port = port;
				
				using(var cwl = new AmazonCloudWatchLogsClient())
				{
					var sRequest = new DescribeLogStreamsRequest("/aws/lambda/"+lambdaFunctions[i]);
					var sResponse = cwl.DescribeLogStreams(sRequest);
				
					foreach (var element in sResponse.LogStreams) {
						li.Add(element.LogStreamName);
					}
					
					temp = DateTime.Parse(st).ToString("yyyy/MM/dd");
					
					string logstream="";
					for (int s = 0; s < li.Count; s++) {
						if (li[s].Contains(temp)) {
							logstream = li[s];
							break;
						}
					}
					var request = new GetLogEventsRequest{
						LogGroupName="/aws/lambda/"+lambdaFunctions[i],
						LogStreamName =logstream,
						StartFromHead = true,
						StartTime=DateTime.Parse(st),
						EndTime=DateTime.Parse(et),
					};
					response = cwl.GetLogEvents(request);
				}
				
				
				ExtractThread ex = new ExtractThread();
				Thread stThread = new Thread(()=>stt= (ex.ExtractStartTime(response)));
				Thread etThread = new Thread(()=>edt=(ex.ExtractEndTime(response)));
				Thread rtThread = new Thread(()=>rpt=(ex.ExtractReport(response)));
				etThread.Start();
				stThread.Start();
				rtThread.Start();
				while (rtThread.IsAlive || stThread.IsAlive || etThread.IsAlive){}
				int ii;
				int jj;
				foreach (var msg in stt) {
					ii=edt.FindIndex(x=> x.Msg == msg.Msg);
					jj=rpt.FindIndex(x=>x.Msg == msg.Msg);
					finalList.Add(new xlUpload(msg.Msg,DateTime.Parse(msg.Timestamp),DateTime.Parse(edt[ii].Timestamp),DateTime.Parse(rpt[jj].Timestamp),Convert.ToDouble(rpt[jj].Duration),Convert.ToDouble(rpt[jj].bDuration),rpt[jj].mSize,rpt[jj].mUsed));
				}
				
			//	DataTable dataTable = new DataTable(typeof(xlUpload).Name);
				DataTable dataTable = new DataTable(lambdaFunctions[i]+i);
	            //Get all the properties
	            PropertyInfo[] Props = typeof(xlUpload).GetProperties(BindingFlags.Public | BindingFlags.Instance);
	            foreach (PropertyInfo prop in Props)
	            {
	                //Setting column names as Property names
	                dataTable.Columns.Add(prop.Name);
	            }
	            foreach (xlUpload item in finalList)
	            {
	                var values = new object[Props.Length];
	                for (int l = 0; l < Props.Length; l++)
	                {
	                    values[l] = Props[l].GetValue(item, null);
	                }
	                dataTable.Rows.Add(values);
	            }   
				var workbook = new XLWorkbook();
				var worksheet = workbook.AddWorksheet(dataTable);
				workbook.SaveAs(filepath+".xlsx");
				
			}
			Console.WriteLine("Please find the report uploaded in the path: "+filepath+".xlsx");
			Console.ReadKey(true);
		}
	}
}