﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/14/2017
 * Time: 4:50 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AWS_Logs
{
	/// <summary>
	/// Description of details.
	/// </summary>
	public class details
	{
		public string Msg{get;set;}
		public string Ingestion{get;set;}
		public string Timestamp{get;set;}
		
		public details(string msg, string timestamp, string ingestion )
		{
			this.Msg = msg;
			this.Ingestion=ingestion;
			this.Timestamp=timestamp;
		}
	}
}
