﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/14/2017
 * Time: 4:41 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Amazon.CloudWatchLogs.Model;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace AWS_Logs
{
	/// <summary>
	/// Description of ExtractThread.
	/// </summary>
	public class ExtractThread
	{
		public List<details> ExtractStartTime(GetLogEventsResponse response)
		{
			List<details> li = new List<details>();
			string re1="START RequestId: ";	// Non-greedy match on filler
	        string re2="([A-Z0-9]{8}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{12})";	// SQL GUID 1
	        string re3=".*?";
			Regex r = new Regex(re1+re2+re3,RegexOptions.IgnoreCase|RegexOptions.Singleline);
			Match m;			
			foreach (var dataPoint in response.Events) {
				m = r.Match(dataPoint.Message);
				if (m.Success) {
					
					li.Add(new details(m.Groups[1].ToString(),dataPoint.Timestamp.ToString(),dataPoint.IngestionTime.ToString()));
				}
			}
			return li;
		}
		public List<details> ExtractEndTime(GetLogEventsResponse response)
		{
			List<details> li = new List<details>();
			string re1="END RequestId: ";	// Non-greedy match on filler
	        string re2="([A-Z0-9]{8}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{12})";	// SQL GUID 1
	        string re3=".*?";
	    
			Regex r = new Regex(re1+re2+re3,RegexOptions.IgnoreCase|RegexOptions.Singleline);
			Match m;			
			foreach (var dataPoint in response.Events) {
				m = r.Match(dataPoint.Message);
				if (m.Success) {
					li.Add(new details(m.Groups[1].ToString(),dataPoint.Timestamp.ToString(),dataPoint.IngestionTime.ToString()));
				}
			}
			return li;
		}
		public List<ReportDetails> ExtractReport(GetLogEventsResponse response)
		{
			//Message: REPORT RequestId: 2491772b-dbf6-11e7-aa86-474fdffcd91e	Duration: 0.26 ms	Billed Duration: 100 ms 	Memory Size: 128 MB	Max Memory Used: 19 MB	,Timestamp: 12/8/2017 8:59:48 AM,Ingestion Time: 12/8/2017 9:00:03 AM
			List<ReportDetails> li = new List<ReportDetails>();
			string re1="REPORT RequestId: ";	// Non-greedy match on filler
	        string re2="([A-Z0-9]{8}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{12})";	// SQL GUID 1
	        string re3=".*?";	        
	        string[] txt2;
	        string msg="";
	        List<string> temp = new List<string>();
			Regex r = new Regex(re1+re2+re3,RegexOptions.IgnoreCase|RegexOptions.Singleline);
			Match m;
			foreach (var datapoint in response.Events) {
				txt2 = datapoint.Message.Split('\t');
				m = r.Match(txt2[0]);
				var test = m.Success;
				if (m.Success) {
					msg = m.Groups[1].ToString();					
					txt2[1]=txt2[1].Replace("Duration: ","");
					txt2[1]=txt2[1].Replace(" ms","");
					txt2[2]=txt2[2].Replace("Billed Duration: ","");
					txt2[2]=txt2[2].Replace(" ms","");
					txt2[3]=txt2[3].Replace("Memory Size: ","");
					txt2[3]=txt2[3].Replace(" MB","");
					txt2[4]=txt2[4].Replace("Max Memory Used: ","");
					txt2[4]=txt2[4].Replace(" MB","");
					li.Add(new ReportDetails(msg,datapoint.Timestamp.ToString(),datapoint.IngestionTime.ToString(),txt2[1],txt2[2],txt2[3],txt2[4]));
		        }				
			}
			return li;
		}
	}
}