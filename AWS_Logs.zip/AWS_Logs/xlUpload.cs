﻿/*
 * Created by SharpDevelop.
 * User: 421448
 * Date: 12/14/2017
 * Time: 7:23 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AWS_Logs
{
	/// <summary>
	/// Description of xlUpload.
	/// </summary>
	public class xlUpload
	{
		public string RequestId{get;set;}
		//public string Ingestion{get;set;}
		public DateTime sTimestamp{get;set;}
		public DateTime eTimestamp{get;set;}
		public DateTime rTimestamp{get;set;}
		public double Duration{get;set;}
		public double bDuration{get;set;}
		public string mSize{get;set;}
		public string mUsed{get;set;}
		
		public xlUpload(string requestId, DateTime stime,DateTime etime,DateTime rtime, double dur, double bDur,string msize, string MUsed )
		{
			this.RequestId = requestId;
			this.sTimestamp=stime;
			this.rTimestamp=rtime;
			this.eTimestamp=etime;
			this.Duration = dur;
			this.bDuration = bDur;
			this.mSize = msize;
			this.mUsed=MUsed;
		}
	}
}
